package com.yash.beans;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Predicate;

public class PasswordVerifier {

	private int counter = 1;

	public String verify(String password) {

		Map<String, Predicate<String>> predicateMap = createPredicateMap();

		if ((predicateMap.get("isNull").negate()).and(predicateMap.get("isLowerCase")).test(password)) {
			Set<Entry<String, Predicate<String>>> entrySet = predicateMap.entrySet();
			entrySet.removeIf(e -> e.getKey().equals("isNull"));
			entrySet.removeIf(e -> e.getKey().equals("isLowerCase"));
			entrySet.stream().forEach(e -> {
				if (e.getValue().test(password))
					counter++;
			});
		}
		if (counter >= 3) {
			return "ok";
		} else {
			throw new RuntimeException(
					"Password should have atleast one uppercase, one lowercase, one digit and have atleast 8 characters");
		}

	}

	private Map<String, Predicate<String>> createPredicateMap() {
		Predicate<String> isNull = pwd -> pwd == null;
		Predicate<String> isLengthGreaterThanEight = pwd -> pwd.length() >= 8;
		Predicate<String> isUpperCase = pwd -> pwd.chars().anyMatch(Character::isUpperCase);
		Predicate<String> isLowerCase = pwd -> pwd.chars().anyMatch(Character::isLowerCase);
		Predicate<String> isDigit = pwd -> pwd.chars().anyMatch(Character::isDigit);

		Map<String, Predicate<String>> predicateMap = new HashMap<>();
		predicateMap.put("isNull", isNull);
		predicateMap.put("isLengthGreaterThanEight", isLengthGreaterThanEight);
		predicateMap.put("isUpperCase", isUpperCase);
		predicateMap.put("isLowerCase", isLowerCase);
		predicateMap.put("isDigit", isDigit);

		return predicateMap;
	}

}
