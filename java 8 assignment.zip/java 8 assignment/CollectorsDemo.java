package com.yash.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CollectorsDemo {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(10, 20, 30, 11, 20, 33, 4, 44, 55, 20);
		
		// collect the result of a Stream into Set
		// collect the result of a Stream into list
		// create Map from the elements of Stream (first remove the duplicates)
		// find summary statistics from a Stream of numbers
		// partition the result of Stream in two parts i.e., odd and even
		// create comma separated string from numbers
		


	}
}
